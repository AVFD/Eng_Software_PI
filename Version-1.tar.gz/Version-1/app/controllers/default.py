from flask import render_template, flash, session, request, redirect, url_for
from flask_login import login_user
from app import app, db
from werkzeug.security import generate_password_hash, check_password_hash

from app.models.tables import User, Admin
from app.models.tables import SecurityKey

@app.route("/index")
@app.route("/")
def index():
    if not session.get('logged_in'):
        return render_template('login.html')
    else:
        return render_template('index.html')


@app.route('/login', methods=['POST'])
def do_admin_login():
    name = request.form['username']
    password = request.form['password']
    if auth_database_check(name, password):
        session['logged_in'] = True
        return index()  
    else:
        return "wrong password!"


@app.route("/createtest")
def createtest():
    if session.get('logged_in'):
        chave = SecurityKey(security_key = "000")
        db.session.add(chave)
        db.session.commit()
        return "ok"
    else:
        return "Voce precisa logar"

@app.route("/logout")
def logout():
    if session.get('logged_in'):
        session['logged_in'] = False
        
    return index()

@app.route("/cadastroSecurityKey")
def cadastrarSecurityKey():
    return render_template("cadastro.html")

@app.route("/SecurityKey/cadastro", methods=['POST'])
def cadastro():
    if request.method == "POST":
        data = request.form.get("SecurityKey")

        if data:
            new_key = SecurityKey(security_key=data)
            db.session.add(new_key)
            db.session.commit()

    return redirect(url_for("index"))

@app.route("/deletarSecurityKey")
def deletar():
    return render_template("delete.html")


@app.route("/SecurityKey/delete", methods=["POST"])
def delete():
        data = request.form.get("SecurityKey")
        itemDelete = SecurityKey.query.filter_by(security_key=data).first()

        if itemDelete:
            db.session.delete(itemDelete)
            db.session.commit()

        return redirect(url_for("index"))

@app.route("/listaSecurityKey")
def lista():
    Keys = SecurityKey.query.all()
    return render_template("lista.html", Keys=Keys)


def auth_database_check(username, userpassword):
    adminTry = Admin.query.filter_by(login_name=username, password=userpassword).first()
    if adminTry:
        return True
    else:
        return False

"""CREATE
@app.route("/teste/<info>")
@app.route("/teste", defaults = {"info": None})
def teste(info):
    i = User("augusto", "600", "Augusto Dias", "augdias@email.com")
    db.session.add(i)
    db.session.commit()

"""
"""UPDATE
@app.route("/teste/<info>")
@app.route("/teste", defaults = {"info": None})
def teste(info):
    r = User.query.filter_by(username="augusto").all()
    print(r)
    return "ok"
"""

















"""
#se colocar "/test/<int:id>", estou forçando ele ser int em vez de
#ser String
@app.route("/test", defaults = {"name": None})
@app.route("/test/<name>")
def test(name = None):

    if name:
        return "Olá, {}!".format(name)
    else:
        return "Olá, usuário!"

@app.route("/temprate")
def temprate():
    #renderiza o template
    return render_template()
"""